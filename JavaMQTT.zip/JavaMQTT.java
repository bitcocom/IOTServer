public class JavaMQTT{	
	public static void main(String[] args) {
		new MqttClass();
	}
} 